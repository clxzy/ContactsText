package com.example.contacttest;

import android.database.sqlite.SQLiteDatabase;

public class MyDatabaseHelper {
    public SQLiteDatabase getReadableDatabase;
}
