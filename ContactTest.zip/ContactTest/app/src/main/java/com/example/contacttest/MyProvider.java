package com.example.contacttest;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MyProvider extends ContentProvider {

    public static final int Contacts_Dir = 0;
    public static final int Contacts_Item = 1;

    public static final String Authority = "com.example.databasetest.provider";

    private static UriMatcher uriMatcher;
    private MyDatabaseHelper dbHelper;

    //Contacts:name,sex,phone
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(Authority,"contacts",Contacts_Dir);
        uriMatcher.addURI(Authority,"contacts/#",Contacts_Item);
    }

    @Override
    public boolean onCreate() {
        return false;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection,
                        @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        //查询
        SQLiteDatabase db = dbHelper.getReadableDatabase;
        Cursor cursor = null;
        switch (uriMatcher.match(uri)){
            case Contacts_Dir:
                //查询所有数据
                cursor = db.query("Contacts",projection,selection,selectionArgs,null,null,sortOrder);
                break;
            case Contacts_Item:
                //查询单条数据
                String name = uri.getPathSegments().get(1);
                cursor = db.query("Contacts",projection,"name=?",new String[]{name},
                        null, null,sortOrder);
                break;
            default:
                break;
        }
        return null;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        switch (uriMatcher.match(uri)) {
            case Contacts_Dir:
                return "vnd.android.cursor.dir/vnd.com.example.databasetest.provider.contacts";
            case Contacts_Item:
                return "vnd.android.cursor.item/vnd.com.example.databasetest.provider.contacts";
        }
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }
}
